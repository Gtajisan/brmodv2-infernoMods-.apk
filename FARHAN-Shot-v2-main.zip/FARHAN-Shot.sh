cd $HOME/FARHAN-Shot && sudo python main.py -i wlan0 -K
